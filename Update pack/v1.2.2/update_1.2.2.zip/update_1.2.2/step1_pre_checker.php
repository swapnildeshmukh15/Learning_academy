if(get_settings('version') == '1.2'){
    \DB::table('settings')->where('type', 'version')->update(['description' => '1.2.1']);
}