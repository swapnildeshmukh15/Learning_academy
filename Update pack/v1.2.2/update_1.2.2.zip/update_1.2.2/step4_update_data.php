use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

if (!Schema::hasColumn('device_ips', 'session_id')) {
Schema::table('device_ips', function(Blueprint $table) {
    $table->text('session_id')->nullable();
});
}


$offline_payment = \DB::table('payment_gateways')->where('identifier', 'offline');
if($offline_payment->count() > 0){
    $offline_data['title'] = 'Offline Payment';
    $offline_data['model_name'] = 'OfflinePayment';
    $offline_data['keys'] = '{"bank_information":"Write your bank information and instructions here"}';
    $offline_data['test_mode'] = '0';
    $offline_data['status'] = '1';
    $offline_data['is_addon'] = '0';
    $offline_data['currency'] = 'USD';
    \DB::table('payment_gateways')->where('identifier', 'offline')->update($offline_data);
}else{
    $offline_data['title'] = 'Offline Payment';
    $offline_data['model_name'] = 'OfflinePayment';
    $offline_data['keys'] = '{"bank_information":"Write your bank information and instructions here"}';
    $offline_data['test_mode'] = '0';
    $offline_data['status'] = '1';
    $offline_data['is_addon'] = '0';
    $offline_data['currency'] = 'USD';
    $offline_data['identifier'] = 'offline';
    \DB::table('payment_gateways')->insert($offline_data);
}