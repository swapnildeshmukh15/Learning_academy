use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;



$paystack_payment = \DB::table('payment_gateways')->where('identifier', 'paystack');
if($paystack_payment->count() > 0){
    $paystack_data['title'] = 'Paystack';
    $paystack_data['model_name'] = 'Paystack';
    $paystack_data['keys'] = '{"secret_test_key":"sk_test_c746060e693dd50c6f397dffc6c3b2f655217c94","public_test_key":"pk_test_0816abbed3c339b8473ff22f970c7da1c78cbe1b","secret_live_key":"sk_live_xxxxxxxxxxxxxxxxxxxxxxxxx","public_live_key":"pk_live_xxxxxxxxxxxxxxxxxxxxxxxxx"}';
    $paystack_data['test_mode'] = '1';
    $paystack_data['status'] = '1';
    $paystack_data['is_addon'] = '0';
    $paystack_data['currency'] = 'NGN';
    \DB::table('payment_gateways')->where('identifier', 'paystack')->update($paystack_data);
}else{
    $paystack_data['title'] = 'Paystack';
    $paystack_data['model_name'] = 'Paystack';
    $paystack_data['keys'] = '{"secret_test_key":"sk_test_c746060e693dd50c6f397dffc6c3b2f655217c94","public_test_key":"pk_test_0816abbed3c339b8473ff22f970c7da1c78cbe1b","secret_live_key":"sk_live_xxxxxxxxxxxxxxxxxxxxxxxxx","public_live_key":"pk_live_xxxxxxxxxxxxxxxxxxxxxxxxx"}';
    $paystack_data['test_mode'] = '1';
    $paystack_data['status'] = '1';
    $paystack_data['is_addon'] = '0';
    $paystack_data['currency'] = 'NGN';
    $paystack_data['identifier'] = 'paystack';
    \DB::table('payment_gateways')->insert($paystack_data);
}