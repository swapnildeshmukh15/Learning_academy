use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

DB::table('builder_pages')->where('is_permanent', null)->update(['html' => '["top_bar","header","hero_banner","features","category","featured_courses","testimonial","about_us","blog","faq","footer"]']);


if (!Schema::hasColumn('lessons', 'total_mark')) {
Schema::table('lessons', function(Blueprint $table) {
    $table->integer('total_mark')->nullable();
});
}

if (!Schema::hasColumn('lessons', 'pass_mark')) {
Schema::table('lessons', function(Blueprint $table) {
    $table->integer('pass_mark')->nullable();
});
}

if (!Schema::hasColumn('lessons', 'retake')) {
Schema::table('lessons', function(Blueprint $table) {
    $table->integer('retake')->nullable();
});
}
