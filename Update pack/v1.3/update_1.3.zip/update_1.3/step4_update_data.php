use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

$seo_field = \DB::table('seo_fields')->where('name_route', 'cookie.policy');
if($seo_field->count() == 0){
    $seo_field_data['route'] = 'Cookie policy';
    $seo_field_data['name_route'] = 'cookie.policy';
    $seo_field_data['meta_title'] = 'Cookie policy';
    $seo_field_data['meta_keywords'] = '[{"value":"Cookie policy"}]';
    $seo_field_data['created_at'] = date('Y-m-d H:i:s');
    \DB::table('seo_fields')->insert($seo_field_data);
}

\DB::table('users')->where('id', '>', 0)->update(['status' => 1, 'email_verified_at' => date('Y-m-d H:i:s')]);

if (\DB::table('player_settings')->where('title', 'animation_speed')->get()->count() == 0) {
    \DB::table('player_settings')->insert(['title' => 'animation_speed', 'description' => '1000']);
}